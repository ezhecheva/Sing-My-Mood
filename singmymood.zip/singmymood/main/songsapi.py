import pprint
import json
import random

import spotipy  # pip install spotipy --upgrade
from spotipy.oauth2 import SpotifyClientCredentials


class Song:
    def __init__(self, id: str, name: str, artist: str, album: str) -> None:
        self.id = id
        self.name = name
        self.artist = artist
        self.album = album

    def __str__(self) -> str:
        return "Song[{}] - name: {}, artist: {}, album: {}".format(
            self.id, self.name, self.artist, self.album
        )


class SpotifyAPI:
    def __init__(self, client_id: str, client_secret: str) -> None:
        auth_manager = SpotifyClientCredentials(
            client_id=client_id, client_secret=client_secret
        )
        self.sp = spotipy.Spotify(auth_manager=auth_manager)

    def search(self, query: str, limit: int = 5) -> list[Song]:
        results = self.sp.search(q=query, limit=limit, type="track")

        return self._extractSongs(results["tracks"]["items"])

    def recommend(self, ids: list[str], limit: int = 5) -> list[Song]:
        random.shuffle(ids)
        ids = ids[:5]
        
        results = self.sp.recommendations(seed_tracks=ids, limit=limit)

        return self._extractSongs(results["tracks"])

    def songs(self, ids: list[str]) -> list[Song]:
        if len(ids) == 0:
            return []

        results = self.sp.tracks(ids)

        return self._extractSongs(results["tracks"])

    def _extractSongs(self, items: dict) -> list[Song]:
        tracks = []
        for item in items:
            id = item["id"]
            name = item["name"]

            artist = item["artists"][0]["name"]
            album = item["album"]["name"]

            tracks.append(Song(id, name, artist, album))

        return tracks


# sp = SpotifyAPI(
#     client_id="31875d44be0945dba747dd908dc98095",
#     client_secret="4e8e67be3e0c43ddaebdf9846ec3abe5",
# )

# tracks = sp.search("fourth of july")

# print("Found")
# for track in tracks:
#     print(track)

# print()

# new = sp.recommend(tracks)

# print("Recommended")
# for track in new:
#     print(track)

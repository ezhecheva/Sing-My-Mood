from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('mood/<str:mood>/', views.mood, name='mood'),
    path('find/<str:mood>/', views.find, name='find'),
    path('add/<str:mood>/', views.add, name='mood'),
    path('recommended/<str:mood>/', views.recommended, name='mood')
]
from genericpath import exists
from django.http import HttpResponse
from django.shortcuts import redirect, render

from main.songsapi import SpotifyAPI

# Create your views here.
sp = SpotifyAPI(
    client_id="31875d44be0945dba747dd908dc98095",
    client_secret="4e8e67be3e0c43ddaebdf9846ec3abe5",
)

FILE_EXT = ".mood"

def home(request):
    return render(request, 'home.html')

def mood(request, mood):
    ids = loadSongs(mood)
    songs = sp.songs(ids)

    return render(request, 'mood.html', {'songs': songs, 'mood': mood})

def find(request, mood):
    q = request.POST['query']

    songs = sp.search(query=q)

    return render(request, 'add.html', {'songs': songs, 'mood': mood})

def add(request, mood):
    ids = set(request.POST.getlist('songs'))

    saved = loadSongs(mood) 
    ids.update(saved)
    saveSongs(mood, ids)

    return redirect("/mood/" + mood)

def recommended(request, mood):
    liked = loadSongs(mood)

    songs = sp.recommend(list(liked))

    return render(request, 'add.html', {'songs': songs, 'mood': mood})

def loadSongs(mood: str) -> set:
    file_name = mood + FILE_EXT

    ids = set()

    if exists(file_name):
        with open(file_name, "r") as f:
            for line in f:
                ids.add(line.strip())

    return set(ids)

def saveSongs(mood: str, ids: set):
    if len(ids) == 0:
        return

    file_name = mood + FILE_EXT

    with open(file_name, "w") as f:
        f.write("\n".join(ids))